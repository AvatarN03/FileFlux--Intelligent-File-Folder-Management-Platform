import FileLists from "../_components/FileLists";

const Files = () => {
  return (
    <div className="mb-10">
      <FileLists />
    </div>
  );
};

export default Files;
