import Folders from "../_components/Folders";

const FoldersPage = () => {
  return (
    <div className="mb-10">
      <Folders />
    </div>
  );
};

export default FoldersPage;
